import { Directive,ElementRef,HostListener,Renderer2 } from '@angular/core';

@Directive({
  selector: '[appMousehover]'
})
export class MousehoverDirective {

  constructor(private elRef:ElementRef,private rend2:Renderer2) { }

  @HostListener('mouseenter') onmouseenter(){

    this.rend2.addClass(this.elRef.nativeElement,'hovered');

  }

  @HostListener('mouseleave') onmouseleave(){

    this.rend2.removeClass(this.elRef.nativeElement,'hovered');
  }

}
