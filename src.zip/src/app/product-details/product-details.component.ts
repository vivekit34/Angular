import { Component } from '@angular/core';
import { ProductsService } from '../services/products.service';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent {
  productsarry:any=[]
  searchProduct: string = '';
  constructor(private productsService:ProductsService, private cartService:CartService){
    productsService.getProductsInfo().subscribe(res => this.productsarry = res);
  }
  ngOnInit(){
  }
  addCart(product:any){
    console.log(product)
    this.cartService.addToCart(product)
    // finding cart length
    this.cartService.onSetCartList(this.cartService.selectedProducts.length)
  }

  addCartService(){
    
  }
}
