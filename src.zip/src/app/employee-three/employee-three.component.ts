import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-three',
  templateUrl: './employee-three.component.html',
  styleUrls: ['./employee-three.component.css']
})
export class EmployeeThreeComponent {
  employeedetails:any =
        {
          name:"Ramesh",
          id:27736638,
          age:34,
          salary:735333,
          path:"./../../assets/images/profile.png"
        }
}
