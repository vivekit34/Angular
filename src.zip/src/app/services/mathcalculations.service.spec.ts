import { TestBed } from '@angular/core/testing';

import { MathcalculationsService } from './mathcalculations.service';

describe('MathcalculationsService', () => {
  let service: MathcalculationsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MathcalculationsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
