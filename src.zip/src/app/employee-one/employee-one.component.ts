import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-one',
  templateUrl: './employee-one.component.html',
  styleUrls: ['./employee-one.component.css']
})
export class EmployeeOneComponent {
        empId:number = 52074135;
        name:string = "Ashok";
        age:number = 26;
        salary:number = 5000

}
