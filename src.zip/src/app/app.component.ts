import { Component } from '@angular/core';
import { ProductsService } from './services/products.service';
import { CartService } from './services/cart.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'project1';
  count:any = 0
  constructor(private cartService:CartService ){
    console.log(cartService.selectedCartCount)
    cartService.selectedCartCount.subscribe((value:any) => {
      this.count = value;
    });

  }
}
