 import { Pipe, PipeTransform } from '@angular/core';

 @Pipe({
 name: 'employeeSearch'
 })
 export class EmployeeSearchPipe implements PipeTransform {
 transform(employees: any[], searchTerm: string): any[] {
 if (!employees || !searchTerm) {
 return employees;
 }

 searchTerm = searchTerm.toLowerCase();
 return employees.filter((employees:any) => {
 const fullName = `${employees.name}`.toLowerCase();
 return fullName.includes(searchTerm);
 });
 }
}
