import { Component } from '@angular/core';

@Component({
  selector: 'app-employee-two',
  templateUrl: './employee-two.component.html',
  styleUrls: ['./employee-two.component.css']
})
export class EmployeeTwoComponent {
        employeedetails:any =
        {
          name:"suresh",
          id:27736637,
          age:35,
          salary:635333,
        }
}
