import { Component } from '@angular/core';

@Component({
  selector: 'app-event-binding',
  templateUrl: './event-binding.component.html',
  styleUrls: ['./event-binding.component.css']
})
export class EventBindingComponent {
  result:any;
addOperation(firstNumber:any, secondNumber:any){
  
this.result = Number(firstNumber)+Number(secondNumber)
}

subOperation(firstNumber:any, secondNumber:any){

  this.result = Number(firstNumber) - Number(secondNumber)
}

divOperation(firstNumber:any, secondNumber:any){

  this.result = Number(firstNumber) / Number(secondNumber)
}

mulOperation(firstNumber:any, secondNumber:any){

  this.result = Number(firstNumber) * Number(secondNumber)
}
}
