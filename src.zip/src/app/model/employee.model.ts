export class Employee {
    id: number | undefined;
    name: string | undefined;
    designation: string | undefined;
    salary: number | undefined;
    
}
