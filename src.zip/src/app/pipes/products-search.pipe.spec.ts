import { ProductsSearchPipe } from './products-search.pipe';

describe('ProductsSearchPipe', () => {
  it('create an instance', () => {
    const pipe = new ProductsSearchPipe();
    expect(pipe).toBeTruthy();
  });
});
