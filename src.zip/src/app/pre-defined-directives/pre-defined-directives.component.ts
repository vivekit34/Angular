import { Component } from '@angular/core';

@Component({
  selector: 'app-pre-defined-directives',
  templateUrl: './pre-defined-directives.component.html',
  styleUrls: ['./pre-defined-directives.component.css']
})
export class PreDefinedDirectivesComponent {
showElements:boolean = false;
course:string = "python"
users:string[] = ["ashok","ravi","ramesh"]
products = [
  {productId: 101, productName :"samsung Tv", productPrice: 50000},
  {productId : 102, productName : "Lg Tv", productPrice: 40000},
  {productId : 103, productName : "sony Tv", productPrice: 30000}
]
}
