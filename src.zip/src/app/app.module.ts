import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { AshokComponent } from './ashok/ashok.component';
import { EmployeeOneComponent } from './employee-one/employee-one.component';
import { EmployeeTwoComponent } from './employee-two/employee-two.component';
import { EmployeeThreeComponent } from './employee-three/employee-three.component';
import { PropertyBindingComponent } from './property-binding/property-binding.component';
import { EventBindingComponent } from './event-binding/event-binding.component';
import { PreDefinedDirectivesComponent } from './pre-defined-directives/pre-defined-directives.component';
import { EmployeeDetailsComponent } from './employee-details/employee-details.component';
import { EmployeeSearchPipe } from './pipes/employee-search.pipe';
import { NewemployeeDetailsComponent } from './newemployee-details/newemployee-details.component';
import { ProductsSearchPipe } from './pipes/products-search.pipe';
import { ProductDetailsComponent } from './product-details/product-details.component';
import { MousehoverDirective } from './directives/mousehover.directive';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MathcalculationComponent } from './mathcalculation/mathcalculation.component';
import { AppRoutingModule } from './app-routing.module';
// import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { AboutComponent } from './about/about.component';
import { ContactComponent } from './contact/contact.component';
import { CartComponent } from './cart/cart.component'
import { CartService } from './services/cart.service';
import { ProductsService } from './services/products.service';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { library } from '@fortawesome/fontawesome-svg-core';
import { faShoppingCart } from '@fortawesome/free-solid-svg-icons';

// const routes: Routes = [
//   {path: 'home', component: HomeComponent},
//   {path: 'about', component: AboutComponent},
//   {path: 'contact', component: ContactComponent}
// ]
library.add(faShoppingCart)

@NgModule({
  declarations: [
    AppComponent,
    AshokComponent,
    EmployeeOneComponent,
    EmployeeTwoComponent,
    EmployeeThreeComponent,
    PropertyBindingComponent,
    EventBindingComponent,
    PreDefinedDirectivesComponent,
    EmployeeDetailsComponent,
    EmployeeSearchPipe,
    NewemployeeDetailsComponent,
    ProductsSearchPipe,
    ProductDetailsComponent,
    MousehoverDirective,
    MathcalculationComponent,
    HomeComponent,
    AboutComponent,
    ContactComponent,
    CartComponent,
  
    

    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    AppRoutingModule,
    FontAwesomeModule,
  
    // RouterModule.forRoot(routes)
  ],
  providers: [CartService,ProductsService,HttpClient],
  bootstrap: [AppComponent]
})
export class AppModule { }
