import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private url:string = "assets/products.json"
  constructor(private httpclient:HttpClient) { }
  selectedProducts:Array<any>=[];
  // Cart counting
  private cartCountData = new BehaviorSubject<any>(0)
  selectedCartCount = this.cartCountData.asObservable();
  
  addToCart(product:any){
    this.selectedProducts.push(product)
      console.log(this.selectedProducts)
 }
//  cart list
  onSetCartList(cartCount:number){
    this.cartCountData.next(cartCount)
  }
}
