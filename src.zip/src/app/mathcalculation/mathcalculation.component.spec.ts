import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MathcalculationComponent } from './mathcalculation.component';

describe('MathcalculationComponent', () => {
  let component: MathcalculationComponent;
  let fixture: ComponentFixture<MathcalculationComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [MathcalculationComponent]
    });
    fixture = TestBed.createComponent(MathcalculationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
