export interface Products {
    id:number;
    name: string;
    price: number;
    quantity: number;
}
