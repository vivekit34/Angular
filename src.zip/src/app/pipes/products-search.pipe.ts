import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'productsSearch'
})
export class ProductsSearchPipe implements PipeTransform {

  transform( Products: any[], searchProduct: string): any[] {
    if (! Products || !searchProduct) {
    return  Products;
    }
   
    searchProduct = searchProduct.toLowerCase();
    return  Products.filter(( Products:any) => {
    const fullName = `${ Products.productName}`.toLowerCase();
    return fullName.includes(searchProduct);
    });
    }
   

}
