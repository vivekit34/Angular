import { Component } from '@angular/core';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent {
  productsarry:any=[]
  totalAmount = 0;
  totalQuantity = 0;
  selectedList:any =[]
  constructor( private cartService:CartService){
    this.selectedList = cartService.selectedProducts;
    console.log(this.selectedList)
    this.getUpdatedTotalAmount();
  }
  remove(p:any){
    this.totalAmount = 0;
    const index = this.selectedList.findIndex((x:any) => x.productName === p.productName);
    this.selectedList.splice(index,1);
    this.getUpdatedTotalAmount();
    this.cartService.onSetCartList(this.cartService.selectedProducts.length)
  }
  
  getUpdatedTotalAmount(){
    this.totalAmount = 0;
    this.totalQuantity = 0;
    this.selectedList.forEach((p:any) => {
      this.totalQuantity = this.totalQuantity + p.quantity;
      this.totalAmount = this.totalAmount + (p.quantity * p.productPrice);
    });
  }
 

}
