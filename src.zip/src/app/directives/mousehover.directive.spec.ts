import { MousehoverDirective } from './mousehover.directive';

describe('MousehoverDirective', () => {
  it('should create an instance', () => {
    const directive = new MousehoverDirective();
    expect(directive).toBeTruthy();
  });
});
