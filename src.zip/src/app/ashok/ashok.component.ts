import { Component } from '@angular/core';

@Component({
  selector: 'app-ashok',
  templateUrl: './ashok.component.html',
  styleUrls: ['./ashok.component.css']
})
export class AshokComponent {

}
