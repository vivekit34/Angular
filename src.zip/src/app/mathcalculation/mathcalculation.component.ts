import { Component } from '@angular/core';
import { MathcalculationsService } from '../services/mathcalculations.service';

@Component({
  selector: 'app-mathcalculation',
  templateUrl: './mathcalculation.component.html',
  styleUrls: ['./mathcalculation.component.css']
})
export class MathcalculationComponent {
  firstNumber!: number;
  secondNumber!: number;
  result!: number;
constructor(private mathcalculationsService:MathcalculationsService){}
addNumbers() {
  this.result = this.mathcalculationsService.add(this.firstNumber, this.secondNumber);
  }
  
  subtractNumbers() {
  this.result = this.mathcalculationsService.subtract(this.firstNumber, this.secondNumber);
  }
  
  multiplyNumbers() {
  this.result = this.mathcalculationsService.multiply(this.firstNumber, this.secondNumber);
  }
  
  divideNumbers() {
  try {
  this.result = this.mathcalculationsService.divide(this.firstNumber, this.secondNumber);
  } catch (error) {
  this.result = NaN; // Handle division by zero error
  console.error(error);
  }
  }
}
