import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NewemployeeDetailsComponent } from './newemployee-details.component';

describe('NewemployeeDetailsComponent', () => {
  let component: NewemployeeDetailsComponent;
  let fixture: ComponentFixture<NewemployeeDetailsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NewemployeeDetailsComponent]
    });
    fixture = TestBed.createComponent(NewemployeeDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
