import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService {

  

  private url:string = "assets/employee.json"
  
  constructor(private httpclient:HttpClient){}
  getEmployeeInfo(){
    return this.httpclient.get(this.url)
  }
}
