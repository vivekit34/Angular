import { Component } from '@angular/core';

@Component({
  selector: 'app-newemployee-details',
  templateUrl: './newemployee-details.component.html',
  styleUrls: ['./newemployee-details.component.css']
})
export class NewemployeeDetailsComponent {

}
