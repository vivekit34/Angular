 import { Component } from '@angular/core';
import { EmployeeDetailsService } from '../services/employee-details.service';
import { NgForm } from '@angular/forms';
 @Component({
   selector: 'app-employee-details',
   templateUrl: './employee-details.component.html',
   styleUrls: ['./employee-details.component.css']
 })
 export class EmployeeDetailsComponent {
    isEditEnabled = false;
   employeeDetailsList:any = []
   searchTerm: string = '';
   selectedIndex: any;
   
  employeeForm = {
    id:0,
    name: '',
    designation: '',
    salary: '',
  };
 
   constructor(employeeDetailsService:EmployeeDetailsService){
     employeeDetailsService.getEmployeeInfo().subscribe(res =>this.employeeDetailsList = res)
   }
   onSubmit(event:any): void {
    this.employeeForm.id = this.employeeDetailsList.length+1;
    this.employeeDetailsList.push(this.employeeForm);
    console.log(JSON.stringify(this.employeeForm, null, 2));
    this.initializeForm();
  }
  initializeForm(){
    this.employeeForm = {
      id:0,
      name: '',
      designation: '',
      salary: '',
    };
  }
  editEmployee(emp:any){
    const i = this.employeeDetailsList.findIndex((x:any) => x.id === emp.id);
    this.isEditEnabled = true;
    this.selectedIndex = i;
    this.employeeForm.id = this.employeeDetailsList[i].id ;
    this.employeeForm.name = this.employeeDetailsList[i].name 
    this.employeeForm.salary = this.employeeDetailsList[i].salary;
    this.employeeForm.designation = this.employeeDetailsList[i].designation;
  }
  saveEmployee(){
    this.isEditEnabled = false;
    this.employeeDetailsList.splice(this.selectedIndex-1,1);
    this.employeeDetailsList.push(this.employeeForm);
    this.employeeDetailsList = this.employeeDetailsList;
    this.initializeForm();
  }
  reset() {
    this.isEditEnabled = false;
  }

  delete(emp:any){
    const i = this.employeeDetailsList.findIndex((x:any) => x.id === emp.id);
    this.employeeDetailsList.splice(i,1)
  }

   onMouseOver(employee: any) {
    employee.hover = true;
    }
    
    onMouseLeave(employee: any) {
      employee.hover = false;
    }

//   Products = [

//          {productId: 201,productName:"LG AC", productPrice:20000,productDesc:"Dual Inverter, AI Convertible",productImg:"assets/images/ac.png"},
    
//       {productId: 202,productName:"Bike", productPrice:25000,productDesc:"Ktm bike",productImg:"assets/images/bike.png"},
    
//        {productId: 203,productName:"Laptop", productPrice:26000,productDesc:"Laptop",productImg:"assets/images/laptop.png"},
    
//          {productId: 204,productName:"Iphone", productPrice:30000,productDesc:"Apple product",productImg:"assets/images/iphone.png"},
    
//         {productId: 205,productName:"Guitar", productPrice:32000,productDesc:"Guitar",productImg:"assets/images/guitar.png"},
    
//         {productId: 206,productName:"Macbook Pro", productPrice:21000,productDesc:"Apple product",productImg:"assets/images/macbook.png"}
    
//       ]
//     searchProduct: string = '';
 }


